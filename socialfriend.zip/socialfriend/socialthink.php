<?php
$archivo="socialthink.txt";
$frases=file($archivo);
shuffle($frases);
echo($frases[0];
?>